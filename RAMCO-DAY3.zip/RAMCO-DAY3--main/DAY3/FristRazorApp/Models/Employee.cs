﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FristRazorApp.Models
{
    public class Employee
    {
        public int EmpId { get; set; }
        public string EName { get; set; }
        public string Designation { get; set; }
    }
}
