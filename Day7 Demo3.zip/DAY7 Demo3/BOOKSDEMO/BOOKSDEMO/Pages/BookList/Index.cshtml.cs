using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BOOKSDEMO.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BOOKSDEMO.Pages.BookList
{
    public class IndexModel : PageModel
    {
        [TempData]
        public string Message { get; set; }

        private readonly BrandNewDB _context;

        public IndexModel(BrandNewDB context)
        {
            this._context = context;
                    }

        public List<Book> Books { get; set; }
    

        public void OnGet()
        {
            Books = _context.Books.ToList();
        }

        public async Task<IActionResult> OnPostDelete(int id)
        {
            var b =await _context.Books.FindAsync(id);
            _context.Books.Remove(b);
      
            _context.SaveChanges();
            Message = b.Title + "is deleted from database";

            return RedirectToPage("Index");
        }
    }
}
