using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BOOKSDEMO.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BOOKSDEMO.Pages.BookList
{
    public class CreateModel : PageModel
    {
        [TempData]
        public string Message { get; set; }

        private readonly BrandNewDB _context;

        public CreateModel(BrandNewDB context)
        {
            this._context = context;
        }

        [BindProperty]
        public Book book { get; set; }

        public void OnGet()
        {

        }

        public IActionResult OnPost()
        {
            _context.Books.Add(book);
            _context.SaveChanges();
            Message = "New Book Added successfully";

            return RedirectToPage("Index");
        }
    }

}
