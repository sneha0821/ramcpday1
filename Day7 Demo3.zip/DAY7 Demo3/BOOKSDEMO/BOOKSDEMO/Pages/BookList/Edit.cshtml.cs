using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BOOKSDEMO.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BOOKSDEMO.Pages.BookList
{
    public class EditModel : PageModel
    {
        [TempData]
        public string Message { get; set; }


        private readonly BrandNewDB _context;

        public EditModel(BrandNewDB context)
        {
            this._context = context;
        }

        [BindProperty]
        public Book Book { get; set; }


        public void OnGet(int id)
        {
            Book = _context.Books.Find(id);
        }

        public async Task<IActionResult> OnPost()
        {
            if (ModelState.IsValid)
            {
                var BookFromDb = _context.Books.Find(Book.BookID);
                BookFromDb.Title = Book.Title;
                BookFromDb.Price = Book.Price;
                BookFromDb.ISBN = Book.ISBN;
                BookFromDb.Author = Book.Author;

                await _context.SaveChangesAsync();

                Message = "Book has been updated successfully";

                return RedirectToPage("Index");
            }

            return RedirectToPage();
        }
    }
}
