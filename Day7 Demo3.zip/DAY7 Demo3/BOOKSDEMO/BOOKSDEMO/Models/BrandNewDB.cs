﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOOKSDEMO.Models
{
    public class BrandNewDB : DbContext
    {
        public BrandNewDB(DbContextOptions<BrandNewDB> Options):base(Options)
        {

        }

        public DbSet<Book> Books { get; set; }
    }
}
